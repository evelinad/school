#!/bin/bash

sudo mn -c
sudo mn --post=post.mn --custom chordtopo.py  --topo chord -x

